-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: airbnb_database
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_equipment` varchar(255) NOT NULL,
  `type_equipment` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,'Wifi','Essentials'),(2,'Washer','Essentials'),(3,'Air conditioning','Essentials'),(4,'Kitchen','Essentials'),(5,'Dryer','Essentials'),(6,'Heating','Essentials'),(7,'TV','Essentials'),(8,'Iron','Essentials'),(9,'Dedicated workspace','Essentials'),(10,'Hair dryer','Essentials'),(11,'Pool','Features'),(12,'Free parking','Features'),(13,'EV charger','Features'),(14,'Hot tub','Features'),(15,'Gym','Features'),(16,'BBQ grill','Features'),(17,'Breakfast','Features'),(18,'Smoking allowed','Features'),(19,'Indor fireplace','Features'),(20,'Beachfront','Location'),(21,'Waterfront','Location'),(22,'Ski-in/ski-ou','Location'),(23,'Smoke alarm','Safety'),(24,'Carbon monoxide alarm','Safety');
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estate`
--

DROP TABLE IF EXISTS `estate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type_estate_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `size` int(11) NOT NULL,
  `num_rooms` int(11) NOT NULL,
  `num_beds` int(11) NOT NULL,
  `description` text,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `allowed_animals` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type_estate_id` (`type_estate_id`),
  CONSTRAINT `estate_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `estate_ibfk_2` FOREIGN KEY (`type_estate_id`) REFERENCES `type_estate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estate`
--

LOCK TABLES `estate` WRITE;
/*!40000 ALTER TABLE `estate` DISABLE KEYS */;
INSERT INTO `estate` VALUES (38,7,1,220.00,430,7,10,'Curabitur ac ex interdum, efficitur orci et, commodo justo. Donec posuere tellus vel nibh bibendum, id accumsan leo pharetra. Morbi dictum, nunc ut congue mattis, orci ante cursus tortor, a accumsan ante diam sit amet diam. In hac habitasse platea dictumst. Curabitur gravida ex at augue blandit feugiat. Nullam velit orci, vulputate id massa et, porta suscipit nunc. Suspendisse non lectus lorem. Etiam efficitur posuere metus vitae rutrum. Quisque ultricies ligula at nibh pharetra semper. Curabitur dignissim sem cursus, gravida lectus at, semper diam. Sed sed sem sed purus condimentum tempor et id sapien. Mauris eu quam hendrerit, vestibulum urna vitae, eleifend justo. Praesent ac convallis erat. Phasellus vel ex ac justo rutrum placerat auctor vitae ante. Cras orci ante, molestie consectetur eleifend a, laoreet at ligula. Maecenas id lacus sed erat maximus congue.','Villefranche-sur-Mer','France',1),(39,7,3,180.00,100,5,8,'Nunc efficitur elementum metus, sed eleifend urna interdum posuere. Etiam tempus vel odio in rhoncus. Vivamus eu neque in diam aliquet consequat id vel libero. Cras tincidunt congue urna, ac fermentum ante. Nam fringilla, risus id consequat aliquam, tellus quam pretium dolor, a pulvinar velit diam a sapien. Pellentesque non magna blandit, fermentum purus sed, commodo risus. Duis risus nulla, blandit quis odio at, cursus congue lectus. Ut faucibus velit eu risus mollis mattis. Donec posuere lorem massa. Integer feugiat dapibus porttitor. Nunc iaculis, nisl sit amet accumsan dapibus, nibh ligula elementum augue, in dapibus dolor mi vitae sem. Aliquam non tellus lacus. Quisque vehicula felis vel lacinia dictum. Nullam ex urna, aliquam et orci eu, elementum efficitur dui.','Barcelona','Spain',0),(40,7,2,120.00,150,3,5,'Vivamus aliquam enim ac venenatis rhoncus. Nulla pretium sed eros vel luctus. Maecenas et magna enim. Curabitur a eros sapien. Quisque commodo luctus nisl, ac mattis neque volutpat et. Donec purus velit, varius vitae turpis a, ultrices vehicula magna. Praesent pharetra euismod neque. Proin porttitor sem et diam ullamcorper, at tristique elit varius. Maecenas rutrum facilisis nibh, in dignissim erat varius non. Suspendisse elementum sapien sit amet libero placerat fermentum. Pellentesque non volutpat nisi, vitae ultricies ante. Pellentesque pharetra est id orci congue, tincidunt auctor lacus pellentesque. Nam molestie ligula orci, ac luctus odio porta tempor. Maecenas in dapibus est.','Antwerp','Belgium',1),(41,8,5,290.00,700,10,15,'Cras ultrices eros ac orci feugiat condimentum. Proin non gravida risus, quis dapibus urna. Curabitur eu massa sit amet ligula gravida efficitur. Ut dignissim est eros, ac tincidunt felis maximus ac. Maecenas nisi quam, laoreet eget mattis eu, rhoncus non risus. Duis gravida, felis in malesuada dictum, nibh justo porta nisi, a condimentum nisl mi ut arcu. Pellentesque at condimentum lorem. Duis tellus sem, consectetur non ullamcorper vel, bibendum fringilla diam. Vivamus arcu erat, scelerisque at mauris sit amet, varius sagittis nulla. In tincidunt finibus metus at vehicula. Sed vel erat at ex viverra blandit quis a diam. Duis mollis tempus ante ac cursus. Mauris eget justo neque.','Antwerp','Belgium',1);
/*!40000 ALTER TABLE `estate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estate_equipment`
--

DROP TABLE IF EXISTS `estate_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estate_equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estate_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `estate_id` (`estate_id`),
  KEY `equipment_id` (`equipment_id`),
  CONSTRAINT `estate_equipment_ibfk_1` FOREIGN KEY (`estate_id`) REFERENCES `estate` (`id`),
  CONSTRAINT `estate_equipment_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estate_equipment`
--

LOCK TABLES `estate_equipment` WRITE;
/*!40000 ALTER TABLE `estate_equipment` DISABLE KEYS */;
INSERT INTO `estate_equipment` VALUES (161,38,1),(162,38,2),(163,38,3),(164,38,4),(165,38,5),(166,38,6),(167,38,7),(168,38,8),(169,38,9),(170,38,10),(171,38,11),(172,38,12),(173,38,20),(174,38,23),(175,38,24),(176,39,4),(177,39,5),(178,39,6),(179,39,7),(180,39,8),(181,39,14),(182,39,20),(183,39,23),(184,39,24),(185,40,2),(186,40,3),(187,40,12),(188,40,13),(189,40,14),(190,40,15),(191,40,23),(192,40,24),(193,41,1),(194,41,2),(195,41,3),(196,41,4),(197,41,5),(198,41,6),(199,41,7),(200,41,8),(201,41,9),(202,41,10),(203,41,11),(204,41,12),(205,41,23),(206,41,24);
/*!40000 ALTER TABLE `estate_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `estate_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `estate_id` (`estate_id`),
  CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`estate_id`) REFERENCES `estate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES (75,8,39),(76,7,41);
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo_estate`
--

DROP TABLE IF EXISTS `photo_estate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo_estate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estate_id` int(11) NOT NULL,
  `photo_estate_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `estate_id` (`estate_id`),
  CONSTRAINT `photo_estate_ibfk_1` FOREIGN KEY (`estate_id`) REFERENCES `estate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo_estate`
--

LOCK TABLES `photo_estate` WRITE;
/*!40000 ALTER TABLE `photo_estate` DISABLE KEYS */;
INSERT INTO `photo_estate` VALUES (47,38,'65000b1764abf_appartement2.jpg'),(48,38,'65000b1764ac2_bathroom1.jpg'),(49,38,'65000b1764ac3_houseGarden3.jpg'),(50,38,'65000b1764ac4_kitchen4.jpg'),(51,38,'65000b1764ac5_Swimmigpool4.jpg'),(52,39,'65000bdf3b441_bathroom3.jpg'),(53,39,'65000bdf3b485_boat1.jpeg'),(54,39,'65000bdf3b486_boat2.jpeg'),(55,39,'65000bdf3b487_kitchen1.jpg'),(56,39,'65000bdf3b488_sea1.jpg'),(57,40,'65000d1d96229_balcon.jpg'),(58,40,'65000d1d9626f_bathroom1.jpg'),(59,40,'65000d1d96271_bedroom.jpg'),(60,40,'65000d1d96272_building2.jpg'),(61,40,'65000d1d96273_kitchen7.jpg'),(62,41,'6500101b3dc2d_houseGarden2.jpg'),(63,41,'6500101b3dc5a_image2.jpg'),(64,41,'6500101b3dc5b_kitchen1.jpg'),(65,41,'6500101b3dc5c_kitchen5.jpg'),(66,41,'6500101b3dc5d_sea2.jpg');
/*!40000 ALTER TABLE `photo_estate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `estate_id` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_finish` date NOT NULL,
  `num_guests` int(11) NOT NULL,
  `are_animals` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `estate_id` (`estate_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`estate_id`) REFERENCES `estate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (1,7,40,'2023-09-13','2023-09-15',4,1),(3,7,39,'2023-09-17','2023-09-18',6,0),(4,7,40,'2023-09-24','2023-09-27',2,1),(5,7,41,'2023-10-01','2023-10-07',5,0),(6,8,39,'2023-10-05','2023-10-07',8,0),(7,7,41,'2023-10-22','2023-10-26',9,0),(8,7,40,'2023-11-01','2023-11-04',5,0),(17,9,38,'2023-09-14','2023-09-20',7,1),(18,9,41,'2023-09-17','2023-09-19',12,1);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_estate`
--

DROP TABLE IF EXISTS `type_estate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_estate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_estate` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_estate`
--

LOCK TABLES `type_estate` WRITE;
/*!40000 ALTER TABLE `type_estate` DISABLE KEYS */;
INSERT INTO `type_estate` VALUES (1,'House'),(2,'Appartement'),(3,'Boat'),(4,'Camper/RV'),(5,'Castle'),(6,'Farm'),(7,'Cave'),(8,'Tent');
/*!40000 ALTER TABLE `type_estate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `second_name` varchar(255) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `photo_user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (7,'Elena','Khramova','elena@example.com','34fba77c7cd14c608c7815c2203fcd13cc5b21ffe8f82fcc80231d96b8a9d1e9ca98eb269bc8203af5a02be2c6444dbf5682ec38a068eb3fee75b2751b15cf71','64f9f200267c2_avatar1.png'),(8,'Stephane','Molano','stephane@example.com','34fba77c7cd14c608c7815c2203fcd13cc5b21ffe8f82fcc80231d96b8a9d1e9ca98eb269bc8203af5a02be2c6444dbf5682ec38a068eb3fee75b2751b15cf71','64f9f27ad1e26_avatar5.png'),(9,'Jane','Doe','jane@example.com','34fba77c7cd14c608c7815c2203fcd13cc5b21ffe8f82fcc80231d96b8a9d1e9ca98eb269bc8203af5a02be2c6444dbf5682ec38a068eb3fee75b2751b15cf71','65029ea73f0f1_avatar3.png');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-18  8:36:09
